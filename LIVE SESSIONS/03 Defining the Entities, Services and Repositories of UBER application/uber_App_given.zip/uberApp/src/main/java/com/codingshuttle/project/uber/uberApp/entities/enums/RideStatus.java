package com.codingshuttle.project.uber.uberApp.entities.enums;

public enum RideStatus {
    CANCELLED, CONFIRMED, ENDED, ONGOING
}
