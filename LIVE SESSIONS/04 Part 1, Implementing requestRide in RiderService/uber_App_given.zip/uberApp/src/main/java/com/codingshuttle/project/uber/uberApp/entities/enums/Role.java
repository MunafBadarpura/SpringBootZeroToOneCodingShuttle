package com.codingshuttle.project.uber.uberApp.entities.enums;

public enum Role {
    ADMIN, DRIVER, RIDER
}
