package com.rudradcruze.project.uber.uberApp.entities.enums;

public enum TransactionMethod {
    BANKING,
    RIDE
}
