package com.rudradcruze.project.uber.uberApp.entities.enums;

public enum RideRequestStatus {
    PENDING,
    CONFIRMED,
    CANCELLED,
}
