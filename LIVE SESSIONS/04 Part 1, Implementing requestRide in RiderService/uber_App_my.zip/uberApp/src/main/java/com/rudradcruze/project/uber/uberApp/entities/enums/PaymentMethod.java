package com.rudradcruze.project.uber.uberApp.entities.enums;

public enum PaymentMethod {
    CASH,
    WALLET
}
