package org.rudradcruze.thirdpartyapi.currencyconvert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyConvertApplication {

    public static void main(String[] args) {
        SpringApplication.run(CurrencyConvertApplication.class, args);
    }

}
