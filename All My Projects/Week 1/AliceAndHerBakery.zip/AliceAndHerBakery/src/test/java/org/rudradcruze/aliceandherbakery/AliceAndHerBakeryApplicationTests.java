package org.rudradcruze.aliceandherbakery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AliceAndHerBakeryApplicationTests {

    @Test
    void contextLoads() {
    }

}
