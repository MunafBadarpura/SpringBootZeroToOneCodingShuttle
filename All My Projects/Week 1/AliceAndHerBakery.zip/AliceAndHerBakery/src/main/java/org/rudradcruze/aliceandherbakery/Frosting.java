package org.rudradcruze.aliceandherbakery;

public interface Frosting {
    String getFrostingType();
}
