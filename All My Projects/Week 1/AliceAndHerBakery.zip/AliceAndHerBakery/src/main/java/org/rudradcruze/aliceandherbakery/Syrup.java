package org.rudradcruze.aliceandherbakery;

public interface Syrup {
    String getSyrupType();
}
