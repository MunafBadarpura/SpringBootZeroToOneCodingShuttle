package org.rudradcruze.datamapping.datamappingtutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataMapingTutorialApplicationTests {

    @Test
    void contextLoads() {
    }

}
