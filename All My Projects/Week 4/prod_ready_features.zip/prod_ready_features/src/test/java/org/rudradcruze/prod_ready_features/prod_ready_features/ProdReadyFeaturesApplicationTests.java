package org.rudradcruze.prod_ready_features.prod_ready_features;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdReadyFeaturesApplicationTests {

    @Test
    void contextLoads() {
    }

}
