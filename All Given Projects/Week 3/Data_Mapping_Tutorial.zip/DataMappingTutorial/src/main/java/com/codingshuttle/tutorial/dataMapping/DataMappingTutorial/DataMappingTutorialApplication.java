package com.codingshuttle.tutorial.dataMapping.DataMappingTutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataMappingTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataMappingTutorialApplication.class, args);
	}

}
